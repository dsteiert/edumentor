﻿window.JoomlaCalLocale = {
	today : "Leo",
	weekend : [0, 6],
	wk : "wk",
	time : "Saa:",
	days : ["Jumapili", "Jumatatu", "Jumanne", "Jumatano", "Alhamisi", "Ijumaa", "Jumamosi"],
	shortDays : ["Jmp", "Jmt", "Jmn", "Jtn", "Alh", "Ijm", "Jmm"],
	months : ["Januari", "Februari", "Machi", "Aprili", "Mai", "Juni", "Julai", "Augosti", "Septemba", "Oktoba", "Novemba", "Desemba"],
	shortMonths : ["Jan", "Feb", "Mach", "Apr", "Mai", "Jun", "Jul", "Ago", "Sep", "Okt", "Nov", "Des"],
	AM : "AM",
	PM :  "PM",
	am : "am",
	pm : "pm",
	dateType : "gregorian",
	minYear : 1900,
	maxYear : 2100,
	exit: "Funga",
	clear: "Safisha"
};