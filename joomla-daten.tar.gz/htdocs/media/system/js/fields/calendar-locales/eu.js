window.JoomlaCalLocale = {
	today : "Gaur",
	weekend : [0, 6],
	wk : "ast.",
	time : "Ordua:",
	days : ["Igandea", "Astelehena", "Asteartea", "Asteazkena", "Osteguna", "Ostirala", "Larunbata"],
	shortDays : ["ig.", "al.", "as.", "az.", "og.", "or.", "lr."],
	months : ["Urtarrila", "Otsaila", "Martxoa", "Apirila", "Maiatza", "Ekaina", "Uztaila", "Abuztua", "Iraila", "Urria", "Azaroa", "Abendua"],
	shortMonths : ["urt.", "ots.", "mar.", "api.", "mai.", "eka.", "uzt.", "abu.", "ira.", "urr.", "aza.", "abe."],
	AM : "AM",
	PM :  "PM",
	am : "am",
	pm : "pm",
	dateType : "gregorian",
	minYear : 1900,
	maxYear : 2100,
	exit: "Itxi",
	clear: "Garbitu"
};
