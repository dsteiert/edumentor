window.JoomlaCalLocale = {
	today : "Heddiw",
	weekend : [0, 6],
	wk : "wy",
	time : "Amser:",
	days : ["Dydd Sul", "Dydd llun", "Dydd Mawrth", "Dydd Mercher", "Dydd Iau", "Dydd Gwener", "Dydd Sadwrn"],
	shortDays : ["Sul", "Llun", "Maw", "Mer", "Iau", "Gwen", "Sad"],
	months : ["Ionawr", "Chwefror", "Mawrth", "Ebrill", "Mai", "Mehefin", "Gorffennaf", "Awst", "Medi", "Hydref", "Tachwedd", "Rhagfyr"],
	shortMonths : ["Ion", "Chw", "Maw", "Ebr", "Mai", "Meh", "Gor", "Awst", "Medi", "Hyd", "Tach", "Rhag"],
	AM : "AM",
	PM :  "PM",
	am : "am",
	pm : "pm",
	dateType : "gregorian",
	minYear : 1900,
	maxYear : 2100,
	exit: "Cau",
	clear: "Clirio"
};