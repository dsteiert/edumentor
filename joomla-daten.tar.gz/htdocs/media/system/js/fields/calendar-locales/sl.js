window.JoomlaCalLocale = {
	today : "Danes",
	weekend : [0, 6],
	wk : "td",
	time : "Čas:",
	days : ["Nedelja", "Ponedeljek", "Torek", "Sreda", "Četrtek", "Petek", "Sobota"],
	shortDays : ["Ned", "Pon", "Tor", "Sre", "Čet", "Pet", "Sob"],
	months : ["Januar", "Februar", "Marec", "April", "Maj", "Junij", "Julij", "Avgust", "September", "Oktober", "November", "December"],
	shortMonths : ["Jan", "Feb", "Mar", "Apr", "Maj", "Jun", "Jul", "Avg", "Sep", "Okt", "Nov", "Dec"],
	AM : "AM",
	PM :  "PM",
	am : "am",
	pm : "pm",
	dateType : "gregorian",
	minYear : 1900,
	maxYear : 2100,
	exit: "Zapri",
	clear: "Počisti"
};